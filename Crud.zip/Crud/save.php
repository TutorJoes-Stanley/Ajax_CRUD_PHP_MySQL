<?php 
	//print_r($_POST);
	$con=new mysqli("localhost","root","","info");
	$n=count($_POST["course"]);
	if($n>=1)
	{
		for($i=0;$i<$n;$i++)
		{
			if(trim($_POST["course"][$i])!='')
			{
				$sql="insert into courses (COURSE) values ('{$_POST["course"][$i]}');";
				$con->query($sql);
			}
		}
		echo "Task Completed";
	}
	else
	{
		echo "No Courses Found";
	}
?>