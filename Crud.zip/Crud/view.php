<?php 
	include "config.php";
?>
<h4 class='page-header'><i class="fa fa-users"></i> Student Details</h4>
<table class="table">
		<tr>
		
			<th>NAME</th>
			<th>AGE</th>
			<th>CITY</th>
			<th>EDIT</th>
			<th>DELETE</th>
		</tr>
		<?php 
			$sql="select * from users";
			$res=$con->query($sql);
			if($res->num_rows>0)
			{
				while($row=$res->fetch_assoc())
				{
					echo"<tr>";
					echo"<td>{$row["NAME"]}</td>";
					echo"<td>{$row["AGE"]}</td>";
					echo"<td>{$row["CITY"]}</td>";
					echo"<td><button type='button' class='btn btn-sm btn-info edit' data-id='{$row["ID"]}'><i class='fa fa-edit'></i></td>";
					echo"<td><button type='button' class='btn btn-sm btn-danger del' data-id='{$row["ID"]}'><i class='fa fa-trash'></i></td>";
					echo"</tr>";
				}
			}
		?>
		
</table>